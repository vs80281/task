import Navbar from "./Components/Navbar";
import CardItems from "./Components/CardItems";
import Leftside from "./Components/Leftside";
import Rightside from "./Components/Rightside";
import Righttop from "./Components/Righttop";
import { Grid, Box } from "@mui/material";

const App = () => {
  return (
    <div>
      <Navbar />

      <Grid container mt={2}>
        <Grid lg={2} md={2} sm={2} mt={4} >
          <Leftside />
        </Grid>
        <Grid lg={6} md={5} sm={10}>
          <CardItems />
        </Grid>
        <Grid lg={3} md={3} sm={10} m={4}>
          <Righttop />
          <br/>
          <Rightside />
        </Grid>
      </Grid>
    </div>
  );
};

export default App;
