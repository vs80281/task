import React from "react";
import styles from "../styles/card.module.css";
import Chip from "@mui/material/Chip";
import Stack from "@mui/material/Stack";
import ThumbUpAltOutlinedIcon from "@mui/icons-material/ThumbUpAltOutlined";
import DriveFolderUploadOutlinedIcon from "@mui/icons-material/DriveFolderUploadOutlined";
import ArrowDropDownCircleOutlinedIcon from "@mui/icons-material/ArrowDropDownCircleOutlined";

const Card = ({ title, heading, Para, image }) => {
  return (
    <>
      <div className={styles.card}>
        <h6 style={{ color: "gray", fontSize: "0.8rem" }}>{title}</h6>
        <h3 style={{ width: "75%", fontSize: "1rem" }}>{heading}</h3>
        <p style={{ width: "75%", fontSize: "1rem", color: "gray" }}>{Para}</p>
        <div className={styles.cardImage}>
          <img style={{ maxWidth: "100%" }} src={image} />
        </div>
        <div className={styles.cardFooter}>
          <Stack direction="row" spacing={1}>
            <Chip
              sx={{ backgroundColor: "white" }}
              icon={<ThumbUpAltOutlinedIcon />}
              label="Relevent"
            />
          </Stack>
          <Stack direction="row" spacing={1}>
            <Chip
              sx={{ backgroundColor: "white" }}
              icon={<DriveFolderUploadOutlinedIcon />}
              label="Share"
            />
          </Stack>
          <Stack direction="row" spacing={1}>
            <Chip
              sx={{ backgroundColor: "white" }}
              icon={<ArrowDropDownCircleOutlinedIcon />}
              label="Read later"
            />
          </Stack>
        </div>
      </div>
    </>
  );
};

export default Card;
