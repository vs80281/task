import React from "react";
import styles from "../styles/cardItems.module.css";
import Card from "./Card";
import Stockdata from "../Data/data";
import { Button } from "@mui/material";
const buttons = [
  "All",
  "Finance",
  "Buisness",
  "Oppurtinity",
  "Personal",
  "Company",
];

const CardItems = () => {
  return (
    <>
      <div>
        <div className={styles.buttonGroup}>
          <h3 style={{ fontSize: "1.5rem" }}>Top Stories for you</h3>
          <div>
            {buttons.map((button) => (
              <Button
                size="small"
                style={{
                  backgroundColor: "lightgray",
                  marginLeft: "2px",
                  borderRadius: "20px",
                  color: "black",
                  textTransform: 'none'
                }}
              >
                {button}
              </Button>
            ))}
          </div>
        </div>
        <ul>
          {Stockdata.map((data) => (
            <Card {...data} />
          ))}
        </ul>
      </div>
    </>
  );
};

export default CardItems;
