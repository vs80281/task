import React from "react";
import styles from "../styles/leftside.module.css";
import { Button } from "@mui/material";
import LocalFireDepartmentIcon from '@mui/icons-material/LocalFireDepartment';

const Leftside = () => {
  return (
    <div className={styles.leftside}>
      <Button
        variant="contained"
      
        startIcon={<LocalFireDepartmentIcon />}
        style={{
          borderRadius: "0px 15px 15px 0px",
          backgroundColor: "white",
          color: "blue",
          textTransform: 'none'
        }}
      >
        Hot Scoopf
      </Button>
      <br />
      <Button
        variant="contained"
        startIcon={<LocalFireDepartmentIcon />}
        style={{
          borderRadius: "0px 15px 15px 0px",
          backgroundColor: "white",
          color: "blue",
          textTransform: 'none'
        }}
      >
         Hot Scoopf
      </Button>
      <br />
      <Button
        variant="contained"
        startIcon={<LocalFireDepartmentIcon />}
        style={{
          borderRadius: "0px 15px 15px 0px",
          backgroundColor: "white",
          color: "blue",
          textTransform: 'none'
        }}
      >
        Hot Scoopf
      </Button>
      <br />
      <Button
        variant="contained"
        startIcon={<LocalFireDepartmentIcon />}
        style={{
          borderRadius: "0px 15px 15px 0px",
          backgroundColor: "white",
          color: "blue",
          textTransform: 'none'
        }}
      >
        Hot Scoopf
      </Button>
      <br />
      <Button
        variant="contained"
        startIcon={<LocalFireDepartmentIcon />}
        style={{
          borderRadius: "0px 15px 15px 0px",
          backgroundColor: "white",
          color: "blue",
          textTransform: 'none'
        }}
      >
        Hot Scoopf
      </Button>
      <br />
      <Button
        variant="contained"
        startIcon={<LocalFireDepartmentIcon />}
        style={{
          borderRadius: "0px 15px 15px 0px",
          backgroundColor: "white",
          color: "blue",
          textTransform: 'none'
        }}
      >
        Hot Scoopf
      </Button>
      <br />
      <Button
        variant="contained"
        startIcon={<LocalFireDepartmentIcon />}
        style={{
          borderRadius: "0px 15px 15px 0px",
          backgroundColor: "white",
          color: "blue",
          textTransform: 'none'
        }}
      >
        Hot Scoopf
      </Button>
      <br />
      <Button
        variant="contained"
        startIcon={<LocalFireDepartmentIcon />}
        style={{
          borderRadius: "0px 15px 15px 0px",
          backgroundColor: "white",
          color: "blue",
          textTransform: 'none'
        }}
      >
        Hot Scoopf
      </Button>
      <br />
      <Button
        variant="contained"
        startIcon={<LocalFireDepartmentIcon />}
        style={{
          borderRadius: "0px 15px 15px 0px",
          backgroundColor: "white",
          color: "blue",
          textTransform: 'none'
        }}
      >
        Hot Scoopf
      </Button>
      <br />
      <Button
        variant="contained"
        startIcon={<LocalFireDepartmentIcon />}
        style={{
          borderRadius: "0px 15px 15px 0px",
          backgroundColor: "white",
          color: "blue",
          textTransform: 'none'
        }}
      >
        Hot Scoopf
      </Button>
      <br />
      <Button
        variant="contained"
        startIcon={<LocalFireDepartmentIcon />}
        style={{
          borderRadius: "0px 15px 15px 0px",
          backgroundColor: "white",
          color: "blue",
          textTransform: 'none'
        }}
      >
        Hot Scoopf
      </Button>
      <br />
    </div>
  );
};

export default Leftside;
