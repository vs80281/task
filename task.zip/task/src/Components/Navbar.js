import React from "react";
import styles from "../styles/navbar.module.css";
import { useState } from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import MenuIcon from "@mui/icons-material/Menu";
import Container from "@mui/material/Container";
import Avatar from "@mui/material/Avatar";
import userAvatar from "../Asset/ToyFaces_Colored_BG_8 2.png";
import vector from "../Asset/Vector.png";
import rectangle from "../Asset/Rectangle.png";
import rectangleorange from "../Asset/RectangleOrange.png";
import Button from "@mui/material/Button";
import Tooltip from "@mui/material/Tooltip";
import MenuItem from "@mui/material/MenuItem";
import logoimage from "../Asset/MicrosoftTeams-image.png";
import Badge from "@mui/material/Badge";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import Chip from "@mui/material/Chip";
import SearchIcon from "@mui/icons-material/Search";

const pages = ["Feed", "Dashboard", "Lookup", "List", "Team"];
const settings = ["Profile", "Account", "Dashboard", "Logout"];

const Navbar = () => {
  const [anchorElNav, setAnchorElNav] = useState(null);
  const [anchorElUser, setAnchorElUser] = useState(null);

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };
  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  return (
    <AppBar position="static" sx={{ backgroundColor: "#FFFFFF" }}>
      <Container maxWidth="xl">
        <Toolbar disableGutters>
          <Typography
            variant="h6"
            noWrap
            component="div"
            sx={{
              color: "#707D85",
              display: { xs: "none", md: "flex" },
            }}
          >
            <img src={logoimage} alt="logo" />
            Zintlr
          </Typography>

          <Box sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}>
            <IconButton
              size="large"
              aria-label="account of current user"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              onClick={handleOpenNavMenu}
              color="inherit"
            >
              <MenuIcon sx={{ color: "#707D85" }} />
            </IconButton>
            <Menu
              id="menu-appbar"
              anchorEl={anchorElNav}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "left",
              }}
              keepMounted
              transformOrigin={{
                vertical: "top",
                horizontal: "left",
              }}
              open={Boolean(anchorElNav)}
              onClose={handleCloseNavMenu}
              sx={{
                display: { xs: "block", md: "none" },
              }}
            >
              {pages.map((page) => (
                <MenuItem key={page} onClick={handleCloseNavMenu}>
                  <Typography textAlign="center">{page} </Typography>
                </MenuItem>
              ))}
            </Menu>
          </Box>
          <Typography
            variant="h6"
            noWrap
            component="div"
            sx={{
              color: "#707D85",
              flexGrow: 1,
              display: { xs: "flex", md: "none" },
            }}
          >
            <img src={logoimage} alt="logo" />
            Zintlr
          </Typography>
          <Box sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } }}>
            {pages.map((page) => (
              <Button
                size="small"
                key={page}
                onClick={handleCloseNavMenu}
                sx={{ color: "#707D85", display: "block", marginLeft: "5px" }}
                style={{ textTransform: "none" }}
              >
                {page}
              </Button>
            ))}
          </Box>
          <Box className={styles.topnav} style={{ position: "relative" }}>
            <input
              placeholder="Search any keyword..."
              type="text"
              style={{ padding: "4px" }}
            />
            <Box
              sx={{ color: "orange" }}
              style={{ position: "absolute", bottom: "1px", left: "85%" }}
            >
              <SearchIcon />
            </Box>
          </Box>
          <Box>
            <Chip
              sx={{ backgroundColor: "white" }}
              avatar={<Avatar alt="Natacha" src={vector} />}
              label="Credits"
            />
            <div>
              <img
                src={rectangle}
                style={{ width: "120px", height: "12.7px" }}
              />
            </div>
            <div>
              <img
                src={rectangleorange}
                style={{
                  position: "relative",
                  bottom: "21px",
                  width: "100px",
                  height: "15px",
                }}
              />
            </div>
          </Box>
          <Box>
            <Badge badgeContent={4} color="warning">
              <NotificationsNoneIcon fontSize="small" color="action" />
            </Badge>

            <Tooltip title="Open settings">
              <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                <Avatar src={userAvatar} sx={{ width: 60, height: 60 }} />
              </IconButton>
            </Tooltip>
            <Menu
              sx={{ mt: "45px" }}
              id="menu-appbar"
              anchorEl={anchorElUser}
              anchorOrigin={{
                vertical: "top",
                horizontal: "right",
              }}
              keepMounted
              transformOrigin={{
                vertical: "top",
                horizontal: "right",
              }}
              open={Boolean(anchorElUser)}
              onClose={handleCloseUserMenu}
            >
              {settings.map((setting) => (
                <MenuItem key={setting} onClick={handleCloseUserMenu}>
                  <Typography textAlign="center">{setting}</Typography>
                </MenuItem>
              ))}
            </Menu>
            <Button
              size="small"
              sx={{
                backgroundColor: "#FFD893",
                color: "#000000",
                borderRadius: "8px",
                padding: "2px",
                marginRight: "0px",
              }}
              style={{ textTransform: "none" }}
            >
              Upgrade
            </Button>
          </Box>
        </Toolbar>
      </Container>
    </AppBar>
  );
};
export default Navbar;
