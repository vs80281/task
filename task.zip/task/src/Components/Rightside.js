import React from "react";
import styles from "../styles/rightside.module.css";
import { useState } from "react";
import { styled } from "@mui/material/styles";
import Chip from "@mui/material/Chip";
import Paper from "@mui/material/Paper";

const ListItem = styled("li")(({ theme }) => ({
  margin: theme.spacing(0.5),
}));
const Rightside = () => {
  const [chipData, setChipData] = useState([
    { key: 0, label: "UX Design" },
    { key: 1, label: "Marketting" },
    { key: 2, label: "expansion" },
    { key: 3, label: "Technology" },
  ]);

  const handleDelete = (chipToDelete) => () => {
    setChipData((chips) =>
      chips.filter((chip) => chip.key !== chipToDelete.key)
    );
  };

  return (
    <>
      <div className={styles.card}>
        <b>Topics to follow</b>
      </div>
      <Paper
        sx={{
          display: "flex",
          justifyContent: "center",
          flexWrap: "wrap",
          listStyle: "none",
          flexDirection: "column",
          p: 0.5,
          m: 0,
        }}
        component="ul"
      >
        {chipData.map((data) => {
          let icon;

          return (
            <ListItem key={data.key} className={styles.cardContent}>
              <Chip
                style={{
                  width: "100%",
                  display: "flex",
                  justifyContent: "space-between",
                  backgroundColor: "white",
                  boxShadow: "px 1px 0px #EFF1F2",
                }}
                icon={icon}
                label={data.label}
                onDelete={
                  data.label === "React" ? undefined : handleDelete(data)
                }
              />
            </ListItem>
          );
        })}
      </Paper>
    </>
  );
};

export default Rightside;
