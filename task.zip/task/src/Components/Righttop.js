import React from "react";
import styles from "../styles/righttop.module.css";
import { useState } from "react";
import { styled } from "@mui/material/styles";
import Chip from "@mui/material/Chip";
import Paper from "@mui/material/Paper";
import SearchIcon from '@mui/icons-material/Search';




const ListItem = styled("li")(({ theme }) => ({
    margin: theme.spacing(0.5),
  }));

const Righttop = () => {
    const [chipData, setChipData] = useState([
        { key: 0, label: "UX Design" },
        { key: 1, label: "python" },
        { key: 2, label: "Expansion" },
        { key: 3, label: "Technology" },
        { key: 4, label: "Legal" },
        { key: 5, label: "New Hire" },
      ]);
  return (
    <>
      <div className={styles.card}>
        <b>Reacent Searches</b>
      </div>
      <Paper
        sx={{
          display: "flex",
          justifyContent: "center",
          flexWrap: "wrap",
          listStyle: "none",
          flexDirection: "column",
          p: 0.5,
          m: 0,
        }}
        component="ul"
      >
        {chipData.map((data) => {
          let icon;

          return (
            <ListItem key={data.key} className={styles.cardContent}>
              <Chip
                style={{
                  width: "100%",
                  display: "flex",
                  justifyContent:"flex-start",
                  backgroundColor: "white",
                  boxShadow: "px 1px 0px #EFF1F2",
                }}
                icon={<SearchIcon/>}
                label={data.label}
                
              />
            </ListItem>
          );
        })}
      </Paper>
    </>
  );
};

export default Righttop;
