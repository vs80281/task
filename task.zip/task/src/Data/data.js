const Stockdata = [
    {
      id: 1,
      title: 'Hot Scoops',
      heading: 'Samsung Galaxy F22 launched in India: Price, features, other details',
      Para: 'Samsung Galaxy F22 has been launched in India. The new smartphone has been priced in the mid-range segment. The new smartphone is powered by a MediaTek chipset and features a high refresh rate AMOLED display.',
      image: 'images/mobile.png',
    },
    {
        id: 2,
        title: 'Hot Scoops',
        heading: 'Samsung Galaxy F22 launched in India: Price, features, other details',
        Para: 'Samsung Galaxy F22 has been launched in India. The new smartphone has been priced in the mid-range segment. The new smartphone is powered by a MediaTek chipset and features a high refresh rate AMOLED display.',
        image: 'images/mobile.png',      },
      {
        id: 3,
        title: 'Hot Scoops',
        heading: 'Samsung Galaxy F22 launched in India: Price, features, other details',
        Para: 'Samsung Galaxy F22 has been launched in India. The new smartphone has been priced in the mid-range segment. The new smartphone is powered by a MediaTek chipset and features a high refresh rate AMOLED display.',
        image: 'images/mobile.png',      },
      {
        id: 4,
        title: 'Hot Scoops',
        heading: 'Samsung Galaxy F22 launched in India: Price, features, other details',
        Para: 'Samsung Galaxy F22 has been launched in India. The new smartphone has been priced in the mid-range segment. The new smartphone is powered by a MediaTek chipset and features a high refresh rate AMOLED display.',
        image: 'images/mobile.png',      },
      {
        id: 5,
        title: 'Hot Scoops',
        heading: 'Samsung Galaxy F22 launched in India: Price, features, other details',
        Para: 'Samsung Galaxy F22 has been launched in India. The new smartphone has been priced in the mid-range segment. The new smartphone is powered by a MediaTek chipset and features a high refresh rate AMOLED display.',
        image: 'images/mobile.png',      },
      {
        id: 6,
        title: 'Hot Scoops',
        heading: 'Samsung Galaxy F22 launched in India: Price, features, other details',
        Para: 'Samsung Galaxy F22 has been launched in India. The new smartphone has been priced in the mid-range segment. The new smartphone is powered by a MediaTek chipset and features a high refresh rate AMOLED display.',
        image: 'images/mobile.png',      },
]

    
  export default Stockdata;